Theme Name: Foundation
Theme URI: http://www.wptouch.com/
Description: The original WPtouch Pro foundation framework (DO NOT USE DIRECTLY)
Version: 4.0
Author: BraveNewCode Inc.