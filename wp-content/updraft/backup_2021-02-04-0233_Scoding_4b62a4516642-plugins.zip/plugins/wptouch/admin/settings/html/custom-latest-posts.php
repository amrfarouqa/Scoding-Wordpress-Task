<?php _e( 'Posts page', 'wptouch-pro' ); ?>

<?php global $latest_post_options; echo $latest_post_options; ?>